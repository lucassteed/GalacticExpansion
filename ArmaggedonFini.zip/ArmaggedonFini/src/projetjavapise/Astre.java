/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;
import java.util.Vector;
import javax.swing.JComponent;

import static projetjavapise.Constantes.*;

/**
 *
 * @author toshiba
 */
public class Astre extends JComponent {

    private Vector<Image> etatsAsteroide = new Vector<>();
    private int taille = new Random().nextInt(51) + 20;
    private int posX = new Random().nextInt(LARGEUR_ECRAN + 1 - (this.taille));
    private int posY = - 1 * this.taille;
    private int vies = new Random().nextInt(3) + 1;
    private int cyclesFin = 10;
    private int accelerateur = new Random().nextInt(7) + 1;
    private int tailleExplosion = new Random().nextInt(250) + 150; 
    private int facteurValeurExplosion = 1;
    
    public Astre() {
        this.etatsAsteroide.add(ASTEROIDE4);
        this.etatsAsteroide.add(ASTEROIDE3);
        this.etatsAsteroide.add(ASTEROIDE2);
        this.etatsAsteroide.add(ASTEROIDE1);
    }

    public int getLimite() {
        return this.posY + this.taille;
    }

    public int getGauche() {
        return this.posX;
    }

    public int getDroite() {
        return this.posX + this.taille;
    }
    
    public void dessiner(Graphics g) {
        if (this.estDedans()){
            g.drawImage(this.etatsAsteroide.get(this.vies), this.posX, this.posY, this.taille, this.taille, this);
        } else {
            g.drawImage(ExplosionVaisseau, this.posX - ((this.tailleExplosion/2) - (this.taille/2)), 
                    500 - this.tailleExplosion, this.tailleExplosion , this.tailleExplosion, this);
        }   
    }

    public void deplacer() {
        this.posY += (1 * this.accelerateur);
    }

    public boolean estDedans() {
        return this.posY < 475 - this.taille;
    }

    public void enleverVie() {
        this.vies--;
        this.facteurValeurExplosion ++;
    }

    public boolean estVivant() {
        return this.vies > 0;
    }

    public void enleverCycleFin() {
        this.cyclesFin--;
    }

    public boolean finCycleFin() {
        return this.cyclesFin == 0;
    }
    
    public int getValeurTouche(){
        return this.taille * this.accelerateur * this.facteurValeurExplosion;
    }
    
    public int getValeurExplosion(){
        return this.tailleExplosion * 10;
    }
}