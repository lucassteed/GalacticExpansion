/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Image;
import java.awt.Toolkit;

/**
 *
 * @author toshiba
 */
public final class Constantes {
    
    public static final int LARGEUR_ECRAN = 750;
    public static final int HAUTEUR_ECRAN = 500;
    public static final Image FOND = Toolkit.getDefaultToolkit().getImage("images/Fond.png");
    public static final Image ASTEROIDE1 = Toolkit.getDefaultToolkit().getImage("images/asteroide1.png");
    public static final Image ASTEROIDE2 = Toolkit.getDefaultToolkit().getImage("images/asteroide2.png");
    public static final Image ASTEROIDE3 = Toolkit.getDefaultToolkit().getImage("images/asteroide3.png");
    public static final Image ASTEROIDE4 = Toolkit.getDefaultToolkit().getImage("images/asteroide5.png");
    
    public static final Image Vaisseau = Toolkit.getDefaultToolkit().getImage("images/Vaisseau.png");
    public static final Image VaisseauDroite = Toolkit.getDefaultToolkit().getImage("images/VaisseauDroite.png");
    public static final Image VaisseauGauche = Toolkit.getDefaultToolkit().getImage("images/VaisseauGauche.png");
    
    public static final Image Vaisseau2 = Toolkit.getDefaultToolkit().getImage("images/Vaisseau2.png");
    public static final Image Vaisseau2Droite = Toolkit.getDefaultToolkit().getImage("images/Vaisseau2Droite.png");
    public static final Image Vaisseau2Gauche = Toolkit.getDefaultToolkit().getImage("images/Vaisseau2Gauche.png");
    
    public static final Image Vaisseau3 = Toolkit.getDefaultToolkit().getImage("images/Vaisseau3.png");
    public static final Image Vaisseau3Droite = Toolkit.getDefaultToolkit().getImage("images/Vaisseau3Droite.png");
    public static final Image Vaisseau3Gauche = Toolkit.getDefaultToolkit().getImage("images/Vaisseau3Gauche.png");
    
    public static final Image ExplosionVaisseau = Toolkit.getDefaultToolkit().getImage("images/ExplosionVaisseau.png");
    
    public static final Image Monnaie = Toolkit.getDefaultToolkit().getImage("images/Monnaie.png");
    
    public static final Image VieVide = Toolkit.getDefaultToolkit().getImage("images/VieVide.png");
    public static final Image ViePleine = Toolkit.getDefaultToolkit().getImage("images/ViePleine.png");
    
    public static final Image Munitions = Toolkit.getDefaultToolkit().getImage("images/Munitions.png");
    public static final Image MunitionsVide = Toolkit.getDefaultToolkit().getImage("images/MunitionsVide.png");
    
    public static final Image Titre = Toolkit.getDefaultToolkit().getImage("images/Titre.png");
    
    public static final Image Gauche = Toolkit.getDefaultToolkit().getImage("images/Gauche.png");
    public static final Image Droite = Toolkit.getDefaultToolkit().getImage("images/Droite.png");
    public static final Image Tir = Toolkit.getDefaultToolkit().getImage("images/Tir.png");
    public static final Image Boost = Toolkit.getDefaultToolkit().getImage("images/Boost.png");
    
    public static final Image Pause = Toolkit.getDefaultToolkit().getImage("images/Pause.png");
}
