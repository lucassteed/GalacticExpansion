/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package projetjavapise;

import java.awt.FontFormatException;
import java.awt.Graphics;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JPanel;
import static projetjavapise.Constantes.Boost;
import static projetjavapise.Constantes.Droite;
import static projetjavapise.Constantes.FOND;
import static projetjavapise.Constantes.Gauche;
import static projetjavapise.Constantes.LARGEUR_ECRAN;
import static projetjavapise.Constantes.Pause;
import static projetjavapise.Constantes.Tir;

/**
 *
 * @author toshiba
 */

public class TouchesPage extends JPanel{
    private JButton boutonRetour;
    private Stylo stylo;
    
    TouchesPage(JButton boutonRetour, Stylo stylo) {
        this.stylo = stylo;
        this.boutonRetour = boutonRetour;
        this.setLayout(null);
        this.boutonRetour.setBounds((LARGEUR_ECRAN - 150) / 2, 395, 150, 50);
        this.add(this.boutonRetour);
    }

    @Override
    public void paintComponent(Graphics g) {
        //super.paintComponent(g);
        g.drawImage(FOND, 0, 0, this.getWidth(), this.getHeight(), this);
        g.drawImage(Constantes.Titre, 80, 30, 600, 120, this);
        
        g.drawImage(Pause, 280, 140, 30, 50, this);
        g.drawImage(Gauche, 270, 200, 45, 30, this);
        g.drawImage(Droite, 270, 245, 45, 30, this);
        g.drawImage(Tir, 275, 290, 30, 35, this);
        g.drawImage(Boost, 240, 335, 80, 27, this);
        
        String gauche = "Gauche";
        String droite = "Droite";
        String tir = "Tir";
        String espace = "Acceleration";

        try {
            this.stylo.ecrire(g, "Pause", 54, 350, 195);          
            this.stylo.ecrire(g, gauche, 54, 350, 240);
            this.stylo.ecrire(g, droite, 54, 350, 285);
            this.stylo.ecrire(g, tir, 54, 350, 330);
            this.stylo.ecrire(g, espace, 54, 350, 375);          
            
        } catch (FontFormatException ex) {
            Logger.getLogger(TouchesPage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(TouchesPage.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
}