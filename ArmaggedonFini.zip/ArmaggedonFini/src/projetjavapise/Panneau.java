/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

/**
 *
 * @author toshiba
 */
import java.awt.Component;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Random;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import static projetjavapise.Constantes.FOND;
import static projetjavapise.Constantes.Monnaie;
import static projetjavapise.Constantes.Munitions;
import static projetjavapise.Constantes.MunitionsVide;

public class Panneau extends JPanel implements Runnable {

    private long tour = 0;
    private Joueur joueur;
    
    /*à mettre dans joueur*/
    private boolean gameover = false;
    
    private boolean enPause = false;
    
    private Vector<Integer> boutonsEnfonces = new Vector<>();
    
    private Vector<Astre> astresExploses = new Vector<>();
    private Vector<Astre> astres = new Vector<>();
    private Vector<Astre> astresMorts = new Vector<>();
    private Vector<Bonus> listeBonus = new Vector<>();
    private Vector<Bonus> bonusAttrapes = new Vector<>();
    private Vector<Bombe> bombes = new Vector<>();
    private String[] listeNomsBonus = {"Points", "Munitions", "Vie"};
    private int derniereDirection = KeyEvent.VK_DOWN;
    private boolean signal = false;
    private Stylo stylo;
    private boolean dashAutorise = false;
    private int level = 0;
    private int acceleration = 0;
    private int accelerationBonus = 0;
    /*la methode appelée à chaque repaint de la Fenetre
    en en hérite mais on la réécrit
    */
    
    public Panneau (Joueur joueur, Stylo stylo){
        this.stylo = stylo;
        this.setLayout(null);
        this.joueur  = joueur;
        this.joueur.forcePosY(500);
    }
    
    public boolean estGameOver(){
        return this.gameover;
    }
    
    public void accelererRythme(){
        if (this.tour % 300 == 0 && !this.gameover){
            this.level ++;
 
            if (!(this.acceleration == 40))
                this.acceleration += 10;
            
            if (!(this.accelerationBonus == 30))
                this.accelerationBonus += 10;
        }
    }
    
    @Override
    public void paintComponent(Graphics g) {

        //pour le score et les logos devant les chiffres
        //g.setFont(new Font(g.getFont().getFontName(), Font.PLAIN, 38));
        //g.drawString("1654", 600, 50);
        g.drawImage(FOND, 0, 0, this.getWidth(), this.getHeight(), null);
        
        /*nouvelle planete toute les 3 secondes*/
        if (this.tour % (50 - this.acceleration) == 0 && this.tour/30 != 0) {
            this.astres.add(new Astre());
        }
        
        String randomBonus = this.listeNomsBonus[new Random().nextInt(this.listeNomsBonus.length)];
        if (this.tour % (40 - this.accelerationBonus) == 0 && this.tour/40 != 0){
            this.listeBonus.add(new Bonus(randomBonus));
        }

        for (int i = 0; i < this.astresExploses.size(); i++) {
            //System.out.println("dessine");
            Astre astreExplose = this.astresExploses.get(i);
            astreExplose.dessiner(g);
            astreExplose.enleverCycleFin();
        }
        
        /*dessiner les bombes puis incrementer*/
        for (int i = 0; i < this.bombes.size(); i++) {

            Bombe bombe = this.bombes.get(i);
            bombe.dessiner(g);
            bombe.deplacer();
        }

        /*dessiner les asteroides puis incrementer*/
        for (int i = 0; i < this.astres.size(); i++) {

            Astre astre = this.astres.get(i);
            astre.dessiner(g);
            astre.deplacer();
        }
        
        for (int i = 0; i < this.listeBonus.size(); i++) {

            Bonus bonus = this.listeBonus.get(i);
            bonus.dessiner(g);
            bonus.deplacer();
        }

        /*dessiner astres morts*/
        for (int i = 0; i < this.astresMorts.size(); i++) {

            Astre astreMort = this.astresMorts.get(i);
            astreMort.dessiner(g);
            astreMort.enleverCycleFin();
        }
        
        
        for (int i = 0; i < this.bonusAttrapes.size(); i++) {

            Bonus bonus = this.bonusAttrapes.get(i);
            bonus.dessiner(g);
            bonus.incrementerCycleFin();
        }

        
        for (int i = 0; i < joueur.getVies() % 4 ; i ++)
            g.drawImage(Constantes.ViePleine, 610 + (i * 42), 67, 40, 40, null);
        
        for (int i = 0; i < 3 - (joueur.getVies() % 4); i ++)
            g.drawImage(Constantes.VieVide, 610 + ((i + (joueur.getVies() % 4)) * 42), 67, 40, 40, null);
        
        //Affichage des munitions
        int munitions = joueur.getMunitions() / 10;
        
        for (int i = 0; i < munitions % 11 ; i ++)
            g.drawImage(Munitions, 520 + (i * 22), 15, 20, 45, null);
        
        for (int i = 0; i < 10 - (munitions % 11); i ++)
            g.drawImage(MunitionsVide, 520 + ((i + (munitions % 11)) * 22), 15, 20, 45, null);
        
        
        /*affichage du score*/
        g.drawImage(Monnaie, 15, 15, 40, 40, null);
        
        try {
            this.stylo.ecrire(g, Integer.toString(this.joueur.getScore()), 84, 72, 72);
        } catch (FontFormatException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        }        
        
        /*vaisseau qui monte au début*/
        if (this.tour / 40 == 0){
            if (this.joueur.getPosY() > 375) this.joueur.forcePosY(this.joueur.getPosY() - 10);
        } else {
            this.joueur.flotter();
        }
       
        /*sens de déplacement du vaisseau*/
        String direction = "Aucun";
        
        if (!(this.tour / 40 == 0 || this.gameover)){
            if (this.boutonsEnfonces.contains(KeyEvent.VK_LEFT)){
                this.joueur.gauche();
                direction = "Gauche";
            }
            if (this.boutonsEnfonces.contains(KeyEvent.VK_RIGHT)){
                this.joueur.droite();
                direction = "Droite";
            }
            if (this.boutonsEnfonces.contains(KeyEvent.VK_UP)) this.ajouterBombe();
        }
        
        /*écrire game over*/
        if (this.gameover) try {
            this.stylo.ecrire(g, "GAME OVER", 118, 100, 225);
        } catch (FontFormatException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /*écrire compte à rebours*/
        if (this.tour / 10 == 0) try {
            this.stylo.ecrire(g, "3", 178, 340, 275);
        } catch (FontFormatException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        else if (this.tour / 20 == 0 && this.tour / 10 > 0) try {
            this.stylo.ecrire(g, "2", 178, 340, 275);
        } catch (FontFormatException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        else if (this.tour / 30 == 0 && this.tour / 20 > 0) try {
            this.stylo.ecrire(g, "1", 178, 340, 275);
        } catch (FontFormatException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        else if (this.tour / 40 == 0 && this.tour / 30 > 0) try {
            this.stylo.ecrire(g, "GO", 178, 290, 275);
        } catch (FontFormatException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (this.tour % 300 < 30 && this.tour / 40 > 0 && !this.gameover){
            try {
                this.stylo.ecrire(g, "Level " + Integer.toString(this.level) , 78, 250, 250);
            } catch (FontFormatException ex) {
                Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        this.joueur.dessiner(g, direction);
        
        this.checkBonusAttrapes();
        this.checkAstresMorts();
        this.checkDepassements();
        this.checkCollisionsAstres();
        this.checkCollisionsBonus();
        
        this.tour++;
        this.accelererRythme();
    }

    private void checkDepassements() {

        if (!this.bombes.isEmpty()) {

            Vector<Bombe> bombesCopie = new Vector<>();

            for (Bombe bombe : this.bombes) {
                if (bombe.estDedans()) {
                    bombesCopie.add(bombe);
                }
            }
            this.bombes = bombesCopie;
        }

        if (!this.astres.isEmpty()) {

            Vector<Astre> astresCp = new Vector<>();

            for (Astre astre : this.astres) {
                if (astre.estDedans()) {
                    //System.out.println(astre.estDedans());
                    astresCp.add(astre);
                    
                } else {
                    /*se declenche seulement si joueur vies == 0*/
                    this.dispatchGameOver();
                    
                    if (!this.gameover){
                        this.joueur.enleverVie();
                        this.joueur.enleverScore(astre.getValeurExplosion());
                    }
                    
                    this.astresExploses.add(astre);
                }
            }
            this.astres = astresCp;
        }
        
        if (!this.listeBonus.isEmpty()) {

            Vector<Bonus> bonusCp = new Vector<>();

            for (Bonus bonus : this.listeBonus) {
                if (bonus.estDedans()) {
                    
                    bonusCp.add(bonus);
                }
            }
            this.listeBonus = bonusCp;
        }
    }

    private void checkCollisionsAstres() {

        /*si il y a une bombe sur l'écran on execute*/
        if (!this.bombes.isEmpty()) {

            /*pour ne plus faire reference à la même liste sinon on change l'originale aussi*/
            Astre astre;
            Bombe bombe;

            int i, j;
            boolean collision;
            
            i = 0;
            collision = false;

            while (!collision && i < this.bombes.size()) {

                bombe = this.bombes.get(i);

                j = 0;
                while (!collision && j < this.astres.size()) {

                    astre = this.astres.get(j);

                    boolean croiseHorizontal = astre.getLimite() >= bombe.getLimite();
                    boolean croiseVertical = (bombe.getGauche() > astre.getGauche() && bombe.getGauche() < astre.getDroite())
                            || (bombe.getDroite() < astre.getDroite() && bombe.getDroite() > astre.getGauche());

                    collision = croiseHorizontal && croiseVertical && astre.getLimite() < 400;

                    /*on fait la copie dans ce sens =>
                    si il y a collision on les retire des copies
                    ça ne marche qu'une fois à cause des index*/
                    if (collision) {
                        Vector<Astre> astresCp = (Vector<Astre>) this.astres.clone();
                        Vector<Bombe> bombesCp = (Vector<Bombe>) this.bombes.clone();

                        astre.enleverVie();
                   
                        if (!this.gameover)
                            this.joueur.ajouterScore(astre.getValeurTouche());

                        if (!astre.estVivant()) {

                            this.astresMorts.add(astresCp.get(j));
                            astresCp.remove(j);
                        }

                        bombesCp.remove(i);

                        /*la copie de la liste moins la collision 
                            ou pas de changements*/
                        this.bombes = bombesCp;
                        this.astres = astresCp;
                    }
                    j++;
                }
                i++;
            }
        }
    }
    
    public void checkCollisionsBonus(){
   /*        */     
   
    if (!this.listeBonus.isEmpty() && !this.gameover){
        int i = 0; 
        boolean collision = false;
        while (i < this.listeBonus.size() && !collision) {
            
            Bonus bonus = this.listeBonus.get(i);
           // bonus.dessiner(g);
            
            boolean croiseHorizontal = bonus.getLimite() >= this.joueur.getLimite();
            boolean croiseVertical = (bonus.getGauche() > this.joueur.getGauche() && bonus.getGauche() < this.joueur.getDroite()) ||  
                    (bonus.getDroite() < this.joueur.getDroite() && bonus.getDroite() > this.joueur.getGauche());

            collision = croiseHorizontal && croiseVertical  && bonus.getLimite() < 400;
            //System.out.println(croiseHorizontal);
            //System.out.println(croiseVertical);
            if (collision){
                //System.out.println("Collision bonus");
                Vector<Bonus> bonusCp = (Vector<Bonus>) this.listeBonus.clone();
                bonus.attraper();
                this.bonusAttrapes.add(this.listeBonus.get(i));
                bonusCp.remove(i);
                
                if (bonus.getTypeBonus().equals("Munitions"))
                    this.joueur.ajouterMunitions();
  
                if (bonus.getTypeBonus().equals("Vie"))
                    this.joueur.ajouterVie();
                
                if (bonus.getTypeBonus().equals("Points"))
                    
                    this.joueur.ajouterScore(bonus.getValeurMonnaie());
                
                this.listeBonus = bonusCp;
            }
            i++;
        }
      }
    }

    public void checkAstresMorts() {
        if (!this.astresMorts.isEmpty()) {

            Vector<Astre> astresMortsCp = new Vector<>();
            for (Astre astreMort : this.astresMorts) {
                if (!astreMort.finCycleFin()) {
                    astresMortsCp.add(astreMort);
                }
            }
            this.astresMorts = astresMortsCp;
        }
        
        if (!this.astresExploses.isEmpty()) {

            Vector<Astre> astresExplosesCp = new Vector<>();
            for (Astre astreExplose : this.astresExploses) {
                if (!astreExplose.finCycleFin()) {
                    astresExplosesCp.add(astreExplose);
                }
            }
            this.astresExploses = astresExplosesCp;
        }
    }

    public void checkBonusAttrapes() {
        if (!this.bonusAttrapes.isEmpty()) {

            Vector<Bonus> bonusAttrapes = new Vector<>();
            for (Bonus bonus : this.bonusAttrapes) {
                if (!bonus.finCycleFin()) {
                    bonusAttrapes.add(bonus);
                }
            }
            this.bonusAttrapes = bonusAttrapes;
        }
    }

    /*events utilisateurs*/
    public void ajouterBombe() {
        
        if (this.joueur.getMunitions() > 0){
            this.bombes.add(new Bombe(this.joueur.getPosX(), this.joueur.getPosY()));
            this.joueur.enleverMunition();
        }
    }
    
    public void togglePause(){
        this.enPause = !this.enPause;
    }
    
    public boolean estEnPause(){
        return this.enPause;
    }
        
    @Override
    public void run() {
        while (!this.enPause && !this.signal) {
            super.repaint();
            try {
                //System.out.println("boucle");
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    public void ajouterBoutonEnfonce(int k){
        
        
        if (!this.boutonsEnfonces.contains(k) && (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_UP)) {
            
            this.boutonsEnfonces.add(k);
            
            if ((k == KeyEvent.VK_LEFT || k == KeyEvent.VK_RIGHT) && !(this.tour / 40 == 0)) 
            {
                this.derniereDirection = k;
                this.dashAutorise = true;
            } else {
                this.dashAutorise = false;
            }
        }
    }
    
    public void enleverBoutonEnfonce(int i){
        if (this.boutonsEnfonces.contains(i)) this.boutonsEnfonces.remove(this.boutonsEnfonces.indexOf(i));
    }
    
    public void dashEvent() {
        
        if (this.boutonsEnfonces.isEmpty() && !this.gameover && this.dashAutorise){
            this.joueur.dash(this.derniereDirection);
            this.dashAutorise = false;
        }
    }
    
    public void dispatchGameOver(){
        
        if (this.joueur.getVies() == 0 && !this.gameover){
            Component c = this;
            while (c.getParent() != null) {            
                    c = c.getParent();
            }
            this.gameover = true;
            ((ActionListener) c).actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "gameover"));
        }
    }
    
    public void declencherSignal(){
        this.signal = true;
    }
}