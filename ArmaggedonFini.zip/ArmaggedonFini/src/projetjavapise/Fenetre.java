/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

/**
 *
 * @author toshiba
 */
import java.awt.FontFormatException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import static projetjavapise.Constantes.LARGEUR_ECRAN;

public class Fenetre extends JFrame implements KeyListener, ActionListener{
    private Stylo stylo = new Stylo("ARCADE");
    private JButton boutonGo = new JButton("GO!");
    private JButton boutonReprendre = new JButton("Reprendre");
    private JButton boutonRecommencer = new JButton("Recommencer");
    private JButton boutonRecommencerGameOver = new JButton("Recommencer");
    //private JButton boutonQuitter = new JButton("Quitter");
    private JButton boutonMenu = new JButton("Accueil");
    private JButton boutonMenuGameOver = new JButton("Accueil");
    private JButton boutonPrevious = new JButton("<");
    private JButton boutonNext = new JButton(">");
    private JButton boutonTouches = new JButton("Touches");
    private JButton boutonScores = new JButton("Meilleur score");
    private JButton boutonRetour1 = new JButton("Retour");
    private JButton boutonRetour2 = new JButton("Retour");
    
    private Sons sons = new Sons();
    
    private PausePage pausePage;
    private StartPage startPage;
    private Panneau panneau;
    private Thread thread;
    private TouchesPage TouchesPages;
    //private ScoresPage scoresPages;
    
    /*j'ai mis le joueur ici pour le séparer du reste => score */
    public Fenetre() throws FontFormatException, IOException {
        
        this.stylo = new Stylo("ARCADE");
        this.startPage = new StartPage(this.boutonGo, this.boutonPrevious, this.boutonNext, this.boutonTouches, this.boutonScores, this.stylo);
        this.pausePage = new PausePage(this.boutonReprendre, this.boutonRecommencer, this.boutonMenu, this.stylo);
        this.TouchesPages = new TouchesPage(this.boutonRetour1, this.stylo);
        //this.scoresPages = new ScoresPage(this.boutonRetour2);
        
        this.boutonGo.addActionListener(this);
        //this.boutonQuitter.addActionListener(this);
        this.boutonPrevious.addActionListener(this);
        this.boutonNext.addActionListener(this);
        this.boutonReprendre.addActionListener(this);
        this.boutonRecommencer.addActionListener(this);
        this.boutonMenu.addActionListener(this);
        this.boutonMenuGameOver.addActionListener(this);
        this.boutonRecommencerGameOver.addActionListener(this);
        this.boutonTouches.addActionListener(this);
        this.boutonRetour1.addActionListener(this);
        this.boutonRetour2.addActionListener(this);
        this.boutonScores.addActionListener(this);
        
        this.addKeyListener(this);
        
        this.setTitle("Harmaggedon");
        this.setSize(750, 500);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        
        this.thread = new Thread(this.startPage);
        this.getContentPane().add(this.startPage);
        this.thread.start();
        this.validate();
        this.setVisible(true);
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        this.panneau.ajouterBoutonEnfonce(e.getKeyCode());
    }

    @Override
    public void keyReleased(KeyEvent e) {
        this.panneau.enleverBoutonEnfonce(e.getKeyCode());
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
        
        
        if (e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyChar() == ' ') {
            //System.out.println("dash demandé");
            this.panneau.dashEvent();
        } else if (e.getKeyChar() == 'P' || e.getKeyChar() == 'p' ||e.getKeyCode() == KeyEvent.VK_ENTER) {
            
            if (!this.panneau.estEnPause() && !this.panneau.estGameOver()){
                
                this.panneau.togglePause();
                
                try {
                    this.thread.join();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Fenetre.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                
                this.setContentPane(this.pausePage);
                
                this.validate();
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource().equals(this.boutonGo) || e.getSource().equals(this.boutonRecommencer)){
           
            this.startPage.stopAnimation();
            
            try {
                this.thread.join();
            } catch (InterruptedException ex) {
                Logger.getLogger(Fenetre.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            this.panneau = new Panneau(new Joueur(this.startPage.getChoix()), this.stylo);
            
            
            this.setContentPane(this.panneau);
            this.requestFocus();
            this.validate();
            
            this.thread = new Thread(this.panneau);
            this.thread.start();
            
        } else if (e.getSource().equals(this.boutonReprendre)){
            this.panneau.togglePause();
            this.thread = new Thread(this.panneau);
            this.setContentPane(this.panneau);
            this.validate();
            this.requestFocus();
            this.thread.start();
            
        /*} else if (e.getSource().equals(this.boutonQuitter)){
            
            if (JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir quitter le jeu?") == 0) 
                this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        
        */} else if (e.getSource().equals(this.boutonMenu)){
            
            //if (JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir retourner à l'accueil?") == 0){ 
                
                this.startPage = new StartPage(this.boutonGo, this.boutonPrevious, this.boutonNext, this.boutonTouches, this.boutonScores, this.stylo);
            
                this.thread = new Thread(this.startPage);
                
                this.thread.start();
                
                this.setContentPane(this.startPage);
                
                this.validate();
            //}
        
        } else if (e.getSource().equals(this.boutonPrevious)){
            this.startPage.previous();
        
        } else if (e.getSource().equals(this.boutonNext)){
            this.startPage.next();
        
        } else if (e.getSource().equals(this.panneau)){
            
            System.out.println("gameover");
            
            this.boutonRecommencerGameOver.setBounds((LARGEUR_ECRAN - 420) / 2 , 250, 200, 75);
            this.boutonMenuGameOver.setBounds(((LARGEUR_ECRAN - 420) / 2) + 210 , 250, 200, 75);
            //this.boutonQuitter.setBounds(((LARGEUR_ECRAN - 480) / 2) + 320 , 250, 150, 50);
            
            this.panneau.add(this.boutonRecommencerGameOver);
            //this.panneau.add(this.boutonQuitter);
            this.panneau.add(this.boutonMenuGameOver);
            
            this.validate();
        
        } else if (e.getSource().equals(this.boutonRecommencerGameOver)){
            
            this.panneau.declencherSignal();
            
            try {
                this.thread.join();
            } catch (InterruptedException ex) {
                Logger.getLogger(Fenetre.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            this.panneau = new Panneau(new Joueur(this.startPage.getChoix()), this.stylo);
            
            this.setContentPane(this.panneau);
            this.requestFocus();
            this.validate();
            
            this.thread = new Thread(this.panneau);
            this.thread.start();
        
        } else if (e.getSource().equals(this.boutonMenuGameOver)){
            
            this.panneau.declencherSignal();
            
            try {
                this.thread.join();
            } catch (InterruptedException ex) {
                Logger.getLogger(Fenetre.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            this.startPage = new StartPage(this.boutonGo, this.boutonPrevious, this.boutonNext, this.boutonTouches, this.boutonScores, this.stylo);
            
            this.thread = new Thread(this.startPage);
            
            this.thread.start();
            
            this.setContentPane(this.startPage);    
            
            this.validate();

        }  else if (e.getSource().equals(this.boutonTouches)){
        
            this.setContentPane(this.TouchesPages);
            this.validate();
        
        } /* else if (e.getSource().equals(this.boutonScores)){
        
            this.setContentPane(this.scoresPages);
            this.validate();
        } */
         else if (e.getSource().equals(this.boutonRetour1) || e.getSource().equals(this.boutonRetour2)){
        
            this.setContentPane(this.startPage);
            this.validate();
        }
    }
}