/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package projetjavapise;

import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JPanel;
import static projetjavapise.Constantes.FOND;
import static projetjavapise.Constantes.LARGEUR_ECRAN;
import static projetjavapise.Constantes.Vaisseau;
import static projetjavapise.Constantes.Vaisseau2;
import static projetjavapise.Constantes.Vaisseau2Droite;
import static projetjavapise.Constantes.Vaisseau2Gauche;
import static projetjavapise.Constantes.Vaisseau3;
import static projetjavapise.Constantes.Vaisseau3Droite;
import static projetjavapise.Constantes.Vaisseau3Gauche;
import static projetjavapise.Constantes.VaisseauDroite;
import static projetjavapise.Constantes.VaisseauGauche;

/**
 *
 * @author toshiba
 */
public class StartPage extends JPanel implements Runnable {

    //private JButton bouton;
    
    private int vaisseauIndex = 0;
    private Vector<Joueur> vaisseaux = new Vector<>();
    private Vector<Vector<Image>> images = new Vector<>();
    private boolean deplacement = false;
    private boolean enCharge = false;
    private boolean ok = false;
    private String sens = "Droite";
    private int cycle = 7;
    private JButton boutonGo;
    private JButton boutonPrevious;
    private JButton boutonNext;
    private Stylo stylo;
    private JButton boutonTouches;
    //private JButton boutonScores;
    
    StartPage(JButton boutonGo, JButton boutonPrevious, JButton boutonNext, JButton boutonTouches, JButton boutonScores, Stylo stylo) {
        
        this.stylo = stylo;
        
        this.boutonGo = boutonGo;
        this.boutonPrevious = boutonPrevious;
        this.boutonNext = boutonNext;
        
        this.boutonPrevious.setEnabled(false);
        this.boutonNext.setEnabled(true);
        
        this.boutonTouches = boutonTouches;
        //this.boutonScores = boutonScores;
        
        this.boutonPrevious.setBounds((LARGEUR_ECRAN - 510)/2, 240, 100, 100);
        this.boutonNext.setBounds(((LARGEUR_ECRAN - 510)/2) + 260 + 250 - 100, 240, 100, 100);
        this.boutonTouches.setBounds((LARGEUR_ECRAN - 510)/2, 365, 150, 75);
        //this.boutonScores.setBounds(((LARGEUR_ECRAN - 510)/2) + 130, 365, 120, 75);
        this.boutonGo.setBounds(((LARGEUR_ECRAN - 510)/2) + 160, 365, 350, 75);

        this.setLayout(null);
        
        this.add(this.boutonGo);
        
        this.add(this.boutonPrevious);
        this.add(this.boutonNext);
        this.add(this.boutonTouches);
        //this.add(this.boutonScores);
        
        
        for (int i = 0; i< 3; i++){
            Vector<Image> imagesVaisseau = new Vector<>();
            
            if (i == 0){
                imagesVaisseau.add(Vaisseau);
                imagesVaisseau.add(VaisseauDroite);
                imagesVaisseau.add(VaisseauGauche);
            } else if (i == 1){
                imagesVaisseau.add(Vaisseau2);
                imagesVaisseau.add(Vaisseau2Droite);
                imagesVaisseau.add(Vaisseau2Gauche);
            
            } else {
                imagesVaisseau.add(Vaisseau3);
                imagesVaisseau.add(Vaisseau3Droite);
                imagesVaisseau.add(Vaisseau3Gauche);
            }
            
            this.images.add(imagesVaisseau);
            Joueur joueur = new Joueur(imagesVaisseau, 50, true);
            joueur.forcePosX(LARGEUR_ECRAN / 2 - 60/2 + (i * 450));
            this.vaisseaux.add(joueur);
        }
        
    }
    
            
    @Override
    public void paintComponent(Graphics g) {
        
        g.drawImage(FOND, 0, 0, this.getWidth(), this.getHeight(), this);
        
        Joueur joueur = null;
        
        if (!this.enCharge) {
        
            try {
                this.stylo.ecrire(g, "Choisissez votre vaisseau", 48, 90, 200);
            } catch (FontFormatException ex) {
                Logger.getLogger(StartPage.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(StartPage.class.getName()).log(Level.SEVERE, null, ex);
            }

            g.drawImage(Constantes.Titre, 75, 30, 600, 120, null);
        
            for (int i = 0 ; i < this.vaisseaux.size(); i++){
                joueur = this.vaisseaux.get(i);
                    
                if (this.deplacement) {    
                    
                    if(this.sens == "Droite") joueur.forcePosX(joueur.getPosX() + 50);
                    else joueur.forcePosX(joueur.getPosX() - 50);
                    
                }
                joueur.flotter();
                joueur.dessiner(g, "Aucun");
            }            
        }
       
        
        this.checkCycleDeplacement();
    }
    
    private void checkCycleDeplacement(){
        
        if (this.deplacement) {
                if (this.cycle > 0) this.cycle--;
                else this.deplacement = false;
        } 
    }
    
    @Override
    public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
   
     if ((infoflags & ImageObserver.ALLBITS) != 0) {
       this.enCharge = false;
       this.repaint();
       return false;
     }
     this.enCharge = true;
     return true;
    } 

    @Override
    public void run() {
        while (!this.ok) {
            super.repaint();
            try {
                //System.out.println("boucle");
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    public void next(){
        if (!this.deplacement){
            this.deplacement = true;
            this.sens = "Gauche";
            this.cycle = 8;
            this.vaisseauIndex++;
            if (!this.boutonPrevious.isEnabled()) this.boutonPrevious.setEnabled(true);
            if (this.vaisseauIndex == 2) this.boutonNext.setEnabled(false);    
        }
    }

    public void previous(){
        if (!this.deplacement){
        
            this.deplacement = true;
            this.sens = "Droite";
            this.cycle = 8;
            this.vaisseauIndex--;
            if (!this.boutonNext.isEnabled()) this.boutonNext.setEnabled(true);
            if (this.vaisseauIndex == 0) this.boutonPrevious.setEnabled(false);
        }
    }

    public void stopAnimation(){
        this.ok = true;
    }

    public Vector<Image> getChoix() {
       return this.images.get(this.vaisseauIndex);
    }
}