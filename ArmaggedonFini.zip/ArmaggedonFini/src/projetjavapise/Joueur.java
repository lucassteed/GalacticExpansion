/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.Vector;
import javax.swing.JComponent;
import static projetjavapise.Constantes.*;

/**
 *
 * @author toshiba
 */
public class Joueur extends JComponent {

    private int score = 0;
    private int vies = 3;
    private int munitions = 100;
    private Vector<Image> vaisseau;
    private int tailleX = 60;
    private int tailleY = 40;
    private int vitesse = 25;
    private int posX = LARGEUR_ECRAN / 2 - (this.tailleX / 2);
    private int posY = 375;
    private int distanceFlottement = 1;
    private long cycleFlottement = 0;
    private boolean descend = true;
    private boolean premierTour = true;

    public Joueur(Vector<Image> vaisseau, int vitesse, boolean auCentre){
        this.vitesse = vitesse;
        this.vaisseau = vaisseau;
        if (auCentre) this.posY = 275; else this.posY = 375;
    }
    
    public Joueur(Vector<Image> vaisseau){
        this.vaisseau = vaisseau;
    }
    
    public void gauche() {
        if (this.posX <= this.tailleX * -1) this.forcePosX(700);
        else this.posX -= this.vitesse;
    }

    public void droite() {
        if (this.posX >= 700) this.forcePosX(this.tailleX * -1);
        this.posX += this.vitesse;  
    }

    public void dessiner(Graphics g, String cote) {
        switch(cote){
            case "Aucun":g.drawImage(this.vaisseau.get(0), this.posX, this.posY, this.tailleX, this.tailleY, this);break;
            case "Droite":g.drawImage(this.vaisseau.get(1), this.posX, this.posY, this.tailleX, this.tailleY, this);break;
            case "Gauche":g.drawImage(this.vaisseau.get(2), this.posX, this.posY, this.tailleX, this.tailleY, this);break;
            default:break;
        }
    }
    
    public void forcePosX(int posX){
        this.posX = posX;
    }
    
    public void forceVitesse(int vitesse){
        this.vitesse = vitesse;
    }

    public int getPosX() {
        return this.posX;
    }
    
    public int getPosY() {
        return this.posY;
    }
    
    public int getLimite(){
        return this.posY;
    }
    
    public int getGauche(){
        return this.posX;
    }
    
    public int getDroite(){
        return this.posX + this.tailleX;
    }
    
    public void dash(int touche){
        if (this.posX + 100 >= 700 && touche == KeyEvent.VK_RIGHT){
            this.forcePosX(100 - (700 - this.posX));
        } else if (this.posX - 100 <= this.tailleX * -1 && touche == KeyEvent.VK_LEFT){
            this.forcePosX(700 - (100 - this.posX));
        } else {
            if (touche == KeyEvent.VK_LEFT) this.posX -= 100;
            else if (touche == KeyEvent.VK_RIGHT) this.posX += 100;
        }
    }
    
    public void flotter(){
        if (this.cycleFlottement % 3 == 0){
                    
            if(this.descend){
                this.distanceFlottement = this.distanceFlottement * -1;
            }
            this.descend = !this.descend;
        }
        this.cycleFlottement ++;
        this.posY += this.distanceFlottement;
    }
    
    public int getVies(){
        return this.vies;
    }
    
    public int getScore(){
        return this.score;
    }
    
    public int getMunitions(){
        return this.munitions;
    }

    void enleverVie() {
        if (this.vies > 0)
        this.vies --;
    }

    public void enleverMunition() {
        if (this.munitions > 0)
        this.munitions--;
    }

    void ajouterMunitions() {
        if (this.munitions < 100)
        this.munitions += 10;
    }

    void ajouterVie() {
        if (this.vies < 3) this.vies++;
    }

    void ajouterScore(int score) {
        this.score += score;
    }
    
    void enleverScore(int score) {
        this.score -= score;
    }

    void forcePosY(int posY){
        this.posY = posY;
    }
}