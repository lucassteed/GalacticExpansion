/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author Lucas
 */

public class Stylo {
        
    private Font font;
    
    public Stylo(String police) throws FontFormatException, IOException{
        
        this.font = Font.createFont(Font.TRUETYPE_FONT, new File("fonts/" + police + ".TTF"));
        GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(this.font);
    }
     
    public void ecrire(Graphics g, String str, int taille, int x, int y) throws FontFormatException, IOException{
        
        g.setFont(new Font(this.font.getFontName(), Font.PLAIN, taille));
        g.setColor(Color.white);
        g.drawString(str, x, y);
    }
}