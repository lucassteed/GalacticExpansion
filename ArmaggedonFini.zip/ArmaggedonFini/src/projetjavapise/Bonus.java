/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;
import javax.swing.JComponent;
import static projetjavapise.Constantes.LARGEUR_ECRAN;

/**
 *
 * @author toshiba
 */
public class Bonus extends JComponent {

   
    private Image imagebonus;
    private String type;
    private int taille = 20;
    private int posX = new Random().nextInt(LARGEUR_ECRAN + 1 - (this.taille));
    private int posY = - 1 * this.taille;
    private boolean attrape = false;
    private long cycleFin = 0;
    private int accelerateur = new Random().nextInt(5) + 10;
    private int valeurMonnaie = (new Random().nextInt(3) + 1) * 100;
    
    public Bonus(String type) {
        this.type = type;
        switch (this.type){
            case "Vie":
                this.imagebonus = Constantes.ViePleine;
                break;
            case "Munitions":
                this.imagebonus = Constantes.Munitions;
                break;
            case "Points":
                this.imagebonus = Constantes.Monnaie;
                break;
            default:break;
        }
    }

    public int getLimite() {
        return this.posY + this.taille;
    }

    public int getGauche() {
        return this.posX;
    }

    public int getDroite() {
        return this.posX + this.taille;
    }

    public void dessiner(Graphics g) {
        
        if (!this.attrape || (this.attrape && !(this.cycleFin % 4 == 0 || this.cycleFin % 4 == 1))){
            if(this.type.equals("Munitions")){
                g.drawImage(this.imagebonus, this.posX, this.posY, 10, 30, this);
            } else if (this.type.equals("Points")) {
                for (int i = 0; i < this.valeurMonnaie/100; i++) 
                    g.drawImage(this.imagebonus, this.posX + (i * 7), this.posY, this.taille, this.taille, this); 
            } else {
                g.drawImage(this.imagebonus, this.posX, this.posY, this.taille, this.taille, this); 
            }
        }
    }

    public void deplacer() {
        this.posY += (1 * this.accelerateur);
    }

    public boolean estDedans() {
        return this.posY < 500 - this.taille;
    }

    public void attraper() {
        this.attrape = true;
    }

    public void incrementerCycleFin() {
        this.cycleFin++;
    }

    public boolean finCycleFin() {
        return this.cycleFin % 28 == 0;
    }

    public String getTypeBonus() {
        return this.type;
    }
    
    public int getValeurMonnaie(){
        return this.valeurMonnaie;
    }
}