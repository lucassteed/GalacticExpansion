/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.applet.Applet;
import java.applet.AudioClip;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 *
 * @author Lucas
 */
public class Sons {
    private static URL s1;
    private static URL s2;

    private static AudioClip tir;
    private static AudioClip explosion;
    
 
    public Sons() throws MalformedURLException {
        
        s1 = new File("sons/monSuperMorceau.wav").toURI().toURL(); 
        
        s2 = new File("sons/tir.wav").toURI().toURL(); 
        
        tir = Applet.newAudioClip(s1);
        explosion = Applet.newAudioClip(s2);
    }
    
    public static void sonTir() {
        tir.play();
    }
    
    public static void sonExplosion() {
        explosion.play();
    }
}
