/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.FontFormatException;
import java.awt.Graphics;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JPanel;
import static projetjavapise.Constantes.FOND;

/**
 *
 * @author toshiba
 */

public class PausePage extends JPanel{

    private JButton boutonReprendre;
    private JButton boutonRecommencer;
    private JButton boutonMenu;
    private Stylo stylo;

    PausePage(JButton boutonReprendre, JButton boutonRecommencer, JButton boutonMenu, Stylo stylo) {
        
        this.stylo = stylo;
        this.boutonReprendre = boutonReprendre;
        this.boutonRecommencer = boutonRecommencer; 
        this.boutonMenu = boutonMenu;
        
        this.setLayout(null);
        
        this.add(this.boutonReprendre);
        this.add(this.boutonRecommencer);
        this.add(this.boutonMenu);

        this.boutonReprendre.setBounds(125, 225, 500, 50);
        this.boutonRecommencer.setBounds(125, 285, 500, 50);
        this.boutonMenu.setBounds(125, 345, 500, 50);
    }

    //private JButton bouton;

    @Override
    public void paintComponent(Graphics g) {
        //super.paintComponent(g);
        
        g.drawImage(FOND, 0, 0, this.getWidth(), this.getHeight(), this);
        g.drawImage(Constantes.Titre, 80, 30, 600, 120, this);
        
        try {
            this.stylo.ecrire(g, "Pause", 74, 275, 215);
        } catch (FontFormatException ex) {
            Logger.getLogger(PausePage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(PausePage.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}