/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import javax.imageio.ImageIO;

/**
 *
 * @author toshiba
 */
public final class Constantes {
    
    public static final int LARGEUR_ECRAN = 750;
    public static final int HAUTEUR_ECRAN = 500;
    public static final Image FOND = Toolkit.getDefaultToolkit().getImage("images/Fond.png");
    public static final Image ASTEROIDE1 = Toolkit.getDefaultToolkit().getImage("images/asteroide1.png");
    public static final Image ASTEROIDE2 = Toolkit.getDefaultToolkit().getImage("images/asteroide3.png");
    public static final Image ASTEROIDE3 = Toolkit.getDefaultToolkit().getImage("images/asteroide4.png");
    public static final Image ASTEROIDE4 = Toolkit.getDefaultToolkit().getImage("images/asteroide5.png");
    
    public static final Image Vaisseau = Toolkit.getDefaultToolkit().getImage("images/Vaisseau.png");
    public static final Image ExplosionVaisseau = Toolkit.getDefaultToolkit().getImage("images/ExplosionVaisseau.png");
    
    public static final Image ArgentSimple = Toolkit.getDefaultToolkit().getImage("images/ArgentSimple.png");
    public static final Image ArgentDouble = Toolkit.getDefaultToolkit().getImage("images/ArgentDouble.png");
    public static final Image ArgentTriple = Toolkit.getDefaultToolkit().getImage("images/ArgentTriple.png");
    
    public static final Image VieVide = Toolkit.getDefaultToolkit().getImage("images/VieVide.png");
    public static final Image ViePleine = Toolkit.getDefaultToolkit().getImage("images/ViePleine.png");
    
    public static final Image Munitions = Toolkit.getDefaultToolkit().getImage("images/Munitions.png");
    
    public static final Image Titre = Toolkit.getDefaultToolkit().getImage("images/Titre.png");
    
    
    
}
