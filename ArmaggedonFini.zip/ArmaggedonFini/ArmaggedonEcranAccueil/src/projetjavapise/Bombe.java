/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author toshiba
 */
public class Bombe {

    private Color couleur = Color.blue;
    private int taille = 10;
    private int posX;
    private int posY;
    
    public Bombe(int posX, int posY){
        this.posX = posX + 25;
        this.posY = posY - 20;
    }
   
    public int getLimite(){
        return this.posY;
    }
    
    public int getGauche(){
        return this.posX;
    }
    
    public int getDroite(){
        return this.posX + this.taille;
    }
    
    public void dessiner(Graphics g){
        g.setColor(this.couleur);
        g.fillOval(this.posX, this.posY, this.taille, this.taille);
    }
    
    public void deplacer(){
        this.posY -= 10;
    }
    
    public boolean estDedans(){
        /*0 c'est le haut*/
        return this.posY >= 0;
    }
}