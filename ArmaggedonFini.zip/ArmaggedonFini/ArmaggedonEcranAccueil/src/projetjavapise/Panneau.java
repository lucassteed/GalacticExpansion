/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

/**
 *
 * @author toshiba
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import static projetjavapise.Constantes.FOND;

public class Panneau extends JPanel implements Runnable {

    private long tour = 0;
    private Joueur joueur = new Joueur();
    public boolean gameover = false;
    public boolean enPause = false;
    private Vector<Astre> astres = new Vector<>();
    private Vector<Astre> astresMorts = new Vector<>();
    private Vector<Bonus> listeBonus = new Vector<>();
    private Vector<Bonus> bonusAttrapes = new Vector<>();
    private Vector<Bombe> bombes = new Vector<>();
    private String[] listeNomsBonus = {"Points", "Munitions", "Vie"};
    /*la methode appelée à chaque repaint de la Fenetre
    en en hérite mais on la réécrit
     */
    @Override
    public void paintComponent(Graphics g) {

        //pour le score et les logos devant les chiffres
        //g.setFont(new Font(g.getFont().getFontName(), Font.PLAIN, 38));
        //g.drawString("1654", 600, 50);
        g.drawImage(FOND, 0, 0, this.getWidth(), this.getHeight(), this);
        
        /*nouvelle planete toute les 3 secondes*/
        if (this.tour % 40 == 0) {
            this.astres.add(new Astre());
        }
        
        String randomBonus = this.listeNomsBonus[new Random().nextInt(this.listeNomsBonus.length)];
        if (this.tour % 20 == 0){
            this.listeBonus.add(new Bonus(randomBonus));
        }

        /*dessiner les bombes puis incrementer*/
        for (int i = 0; i < this.bombes.size(); i++) {

            Bombe bombe = this.bombes.get(i);
            bombe.dessiner(g);
            bombe.deplacer();
        }

        /*dessiner les asteroides puis incrementer*/
        for (int i = 0; i < this.astres.size(); i++) {

            Astre astre = this.astres.get(i);
            astre.dessiner(g);
            astre.deplacer();
        }
        
        for (int i = 0; i < this.listeBonus.size(); i++) {

            Bonus bonus = this.listeBonus.get(i);
            bonus.dessiner(g);
            bonus.deplacer();
        }

        /*dessiner astres morts*/
        for (int i = 0; i < this.astresMorts.size(); i++) {

            Astre astreMort = this.astresMorts.get(i);
            astreMort.dessiner(g);
            astreMort.enleverCycleFin();
        }
        
        for (int i = 0; i < this.bonusAttrapes.size(); i++) {

            Bonus bonus = this.bonusAttrapes.get(i);
            bonus.dessiner(g);
            bonus.incrementerCycleFin();
        }

        this.checkBonusAttrapes();
        this.checkAstresMorts();
        this.checkDepassements();
        this.checkCollisionsAstres();
        this.checkCollisionsBonus();
        
        this.joueur.dessiner(g);
        
        this.tour++;
    }

    private void checkDepassements() {

        if (!this.bombes.isEmpty()) {

            Vector<Bombe> bombesCopie = new Vector<>();

            for (Bombe bombe : this.bombes) {
                if (bombe.estDedans()) {
                    bombesCopie.add(bombe);
                }
            }
            this.bombes = bombesCopie;
        }

        if (!this.astres.isEmpty()) {

            Vector<Astre> astresCp = new Vector<>();

            for (Astre astre : this.astres) {
                if (astre.estDedans()) {
                    //System.out.println(astre.estDedans());
                    astresCp.add(astre);
                } /*else {
                    this.gameover = true;
                }*/
            }
            this.astres = astresCp;
        }
        
        if (!this.listeBonus.isEmpty()) {

            Vector<Bonus> bonusCp = new Vector<>();

            for (Bonus bonus : this.listeBonus) {
                if (bonus.estDedans()) {
                    
                    bonusCp.add(bonus);
                }
            }
            this.listeBonus = bonusCp;
        }
    }

    private void checkCollisionsAstres() {

        /*si il y a une bombe sur l'écran on execute*/
        if (!this.bombes.isEmpty()) {

            /*pour ne plus faire reference à la même liste sinon on change l'originale aussi*/
            Astre astre;
            Bombe bombe;

            int i, j;
            boolean collision;

            i = 0;
            collision = false;

            while (!collision && i < this.bombes.size()) {

                bombe = this.bombes.get(i);

                j = 0;
                while (!collision && j < this.astres.size()) {

                    astre = this.astres.get(j);

                    boolean croiseHorizontal = astre.getLimite() >= bombe.getLimite();
                    boolean croiseVertical = astre.getGauche() < bombe.getGauche()
                            && astre.getDroite() > bombe.getDroite();

                    collision = croiseHorizontal && croiseVertical;

                    /*on fait la copie dans ce sens =>
                    si il y a collision on les retire des copies
                    ça ne marche qu'une fois à cause des index*/
                    if (collision) {
                        Vector<Astre> astresCp = (Vector<Astre>) this.astres.clone();
                        Vector<Bombe> bombesCp = (Vector<Bombe>) this.bombes.clone();

                        astre.enleverVie();

                        if (!astre.estVivant()) {

                            this.astresMorts.add(astresCp.get(j));
                            astresCp.remove(j);
                        }

                        bombesCp.remove(i);

                        /*la copie de la liste moins la collision 
                            ou pas de changements*/
                        this.bombes = bombesCp;
                        this.astres = astresCp;
                    }
                    j++;
                }
                i++;
            }
        }
    }
    
    public void checkCollisionsBonus(){
   /*        */     
   
    if (!this.listeBonus.isEmpty()){
        int i = 0; 
        boolean collision = false;
        while (i < this.listeBonus.size() && !collision) {
            
            Bonus bonus = this.listeBonus.get(i);
           // bonus.dessiner(g);
            
            boolean croiseHorizontal = bonus.getLimite() >= this.joueur.getLimite();
            boolean croiseVertical = bonus.getGauche() - 50 <= this.joueur.getGauche()
                    && bonus.getDroite() + 50 >= this.joueur.getDroite();

            collision = croiseHorizontal && croiseVertical  && !(bonus.getLimite() > 450);
            //System.out.println(croiseHorizontal);
            //System.out.println(croiseVertical);
            if (collision){
                //System.out.println("Collision bonus");
                Vector<Bonus> bonusCp = (Vector<Bonus>) this.listeBonus.clone();
                bonus.attraper();
                this.bonusAttrapes.add(this.listeBonus.get(i));
                bonusCp.remove(i);    
                this.listeBonus = bonusCp;
            }
            i++;
        }
      }
    }

    public void checkAstresMorts() {
        if (!this.astresMorts.isEmpty()) {

            Vector<Astre> astresMortsCp = new Vector<>();
            for (Astre astreMort : this.astresMorts) {
                if (!astreMort.finCycleFin()) {
                    astresMortsCp.add(astreMort);
                }
            }
            this.astresMorts = astresMortsCp;
        }
    }

    public void checkBonusAttrapes() {
        if (!this.bonusAttrapes.isEmpty()) {

            Vector<Bonus> bonusAttrapes = new Vector<>();
            for (Bonus bonus : this.bonusAttrapes) {
                if (!bonus.finCycleFin()) {
                    bonusAttrapes.add(bonus);
                }
            }
            this.bonusAttrapes = bonusAttrapes;
        }
    }

    /*events utilisateurs*/
    public void ajouterBombeEvent() {
        this.bombes.add(new Bombe(this.joueur.getPosX(), this.joueur.getPosY()));
    }

    public void droiteEvent() {
        this.joueur.droite();
    }

    public void gaucheEvent() {
        this.joueur.gauche();
    }

    public void dashEvent(int derniereTouche) {
        this.joueur.dash(derniereTouche);
    }
    
    public void togglePause(){
        this.enPause = !this.enPause;
    }
    
    public boolean estEnPause(){
        return this.enPause;
    }
        
    @Override
    public void run() {
        while (!this.enPause) {
            super.repaint();
            try {
                //System.out.println("boucle");
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    
    }
}