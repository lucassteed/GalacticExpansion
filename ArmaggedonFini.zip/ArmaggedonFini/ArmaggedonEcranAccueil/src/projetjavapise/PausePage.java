/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Graphics;
import javax.swing.JPanel;
import static projetjavapise.Constantes.FOND;

/**
 *
 * @author toshiba
 */

public class PausePage extends JPanel implements Runnable {

    //private JButton bouton;

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(FOND, 0, 0, this.getWidth(), this.getHeight(), this);
        g.drawImage(Constantes.Titre, 80, 30, 600, 120, this);
    }

    @Override
    public void run() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
