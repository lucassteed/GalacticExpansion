/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import static projetjavapise.Constantes.*;

/**
 *
 * @author toshiba
 */
public class Joueur {

    private Color couleur = Color.black;
    private int score = 0;
    private int tailleX = 60;
    private int tailleY = 40;
    private int posX = LARGEUR_ECRAN / 2 - (this.tailleX / 2);
    private int posY = 400;
    private int distanceFlottement = 1;
    private long cycleFlottement = 0;
    private boolean descend = true;
    private boolean premierTour = true;

    public void gauche() {
        if (this.posX > 0) {
            this.posX -= 10;
        }
    }

    public void droite() {
        if (this.posX < LARGEUR_ECRAN - this.tailleX) {
            this.posX += 10;
        }  
    }

    public void dessiner(Graphics g) {
        this.flotter();
        g.drawImage(Constantes.Vaisseau, this.posX, this.posY, this.tailleX, this.tailleY, null);
    }

    public int getPosX() {
        return this.posX;
    }
    
    public int getPosY() {
        return this.posY;
    }
    
    public int getLimite(){
        return this.posY;
    }
    
    public int getGauche(){
        return this.posX;
    }
    
    public int getDroite(){
        return this.posX + this.tailleX;
    }
    
    public void dash(int touche){
        
        if (touche == 1) this.posX -= 100;
        else this.posX += 100;
    }
    
    public void flotter(){
        if (this.cycleFlottement % 3 == 0){
                    
            if(this.descend){
                this.distanceFlottement = this.distanceFlottement * -1;
            }
            this.descend = !this.descend;
        }
        this.cycleFlottement ++;
        this.posY += this.distanceFlottement;
    }
}