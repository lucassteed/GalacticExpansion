/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

/**
 *
 * @author toshiba
 */
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static projetjavapise.Constantes.FOND;
import static projetjavapise.Constantes.LARGEUR_ECRAN;

public class Fenetre extends JFrame implements KeyListener, ActionListener {

    private Panneau panneau;
    private final StartPage startPage = new StartPage();
    private final PausePage pausePage = new PausePage();
    
    private final JButton boutonGo = new JButton("Commencer");
    private final JButton boutonReprendre = new JButton("Reprendre");
    private final JButton boutonRecommencer = new JButton("Recommencer");
    private final JButton boutonQuitter = new JButton("Quitter");
    private final JButton boutonMenu = new JButton("Menu");
    
    private int dernierTouche = 0;
    
    private Thread thread;
    
    /*j'ai mis le joueur ici pour le séparer du reste => score */
    public Fenetre() {

        this.startPage.setLayout(null);
        this.boutonGo.setBounds((LARGEUR_ECRAN - 510)/2, 375, 250, 50);
        this.boutonGo.addActionListener(this);
        this.boutonQuitter.setBounds(((LARGEUR_ECRAN - 510)/2) + 260, 375, 250, 50);
        this.boutonQuitter.addActionListener(this);
        this.startPage.add(this.boutonGo);
        this.startPage.add(this.boutonQuitter);
        
        this.pausePage.setLayout(null);
        this.boutonReprendre.setBounds(125, 200, 500, 50);
        this.boutonRecommencer.setBounds(125, 260, 500, 50);
        this.boutonMenu.setBounds(125, 320, 500, 50);
        this.boutonReprendre.addActionListener(this);
        this.boutonRecommencer.addActionListener(this);
        this.boutonMenu.addActionListener(this);
        this.pausePage.add(this.boutonReprendre);
        this.pausePage.add(this.boutonRecommencer);
        this.pausePage.add(this.boutonMenu);
                
        this.addKeyListener(this);
        this.setTitle("Harmaggedon");
        this.setSize(750, 500);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.getContentPane().add(this.startPage);
        this.setVisible(true);
    }

    @Override
    public void keyPressed(KeyEvent e) {

        if (e.getKeyChar() == '1') {
            this.panneau.gaucheEvent();
            this.dernierTouche = 1;
            //repaint();
        } else if (e.getKeyChar() == '2') {
            this.panneau.droiteEvent();
            this.dernierTouche = 2;
            //repaint();
        } else if (e.getKeyChar() == '3') {
            this.panneau.ajouterBombeEvent();
            //repaint();
        } else if (e.getKeyChar() == ' ') {
            this.panneau.dashEvent(this.dernierTouche);
        } else {

        }
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        //System.out.println("key released!");
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
        if (e.getKeyChar() == 'p') {
            if (!this.panneau.estEnPause()){
                
                this.panneau.togglePause();
                
                try {
                    this.thread.join();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Fenetre.class.getName()).log(Level.SEVERE, null, ex);
                }
                this.setContentPane(this.pausePage);
                this.validate();
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(this.boutonGo) || e.getSource().equals(this.boutonRecommencer)){
            this.panneau = new Panneau();
            this.setContentPane(this.panneau);
            this.requestFocus();
            this.validate();
            this.thread = new Thread(this.panneau);
            this.thread.start();
  
        } else if (e.getSource().equals(this.boutonReprendre)){
            this.panneau.togglePause();
            this.thread = new Thread(this.panneau);
            this.setContentPane(this.panneau);
            this.validate();
            this.requestFocus();
            this.thread.start();
            
        } else if (e.getSource().equals(this.boutonQuitter)){
            
            if (JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir quitter le jeu?") == 0) 
                this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        
        }else if (e.getSource().equals(this.boutonMenu)){
            
            if (JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir retourner au menu?\nvotre partie sera perdue...") == 0){ 
                    this.setContentPane(this.startPage);
                    //this.requestFocus();
                    this.validate();
            }
        }
    }
}