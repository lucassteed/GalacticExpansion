/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;
import java.util.Vector;
import static projetjavapise.Constantes.LARGEUR_ECRAN;

/**
 *
 * @author toshiba
 */
public class Bonus {

   
    private Image imagebonus;
    private String type;
    private int taille = 20;
    private int posX = new Random().nextInt(LARGEUR_ECRAN + 1 - (this.taille));
    private int posY = - 1 * this.taille;
    private boolean attrape = false;
    private long cycleFin = 0;
    private int accelerateur = new Random().nextInt(5) + 10;

    public Bonus(String type) {
        switch (type){
            case "Vie":
                this.imagebonus = Constantes.ViePleine;
                break;
            case "Munitions":
                this.imagebonus = Constantes.Munitions;
                break;
            case "Points":
                this.imagebonus = Constantes.ArgentSimple;
                break;
            default:break;
        }
    }

    public int getLimite() {
        return this.posY + this.taille;
    }

    public int getGauche() {
        return this.posX - 10;
    }

    public int getDroite() {
        return this.posX + this.taille + 10;
    }

    public void dessiner(Graphics g) {
        if (!this.attrape){
            
        } else {
            g.setColor(Color.red);
        }
        g.drawImage(this.imagebonus, this.posX, this.posY, this.taille, this.taille, null);
    }

    public void deplacer() {
        this.posY += (1 * this.accelerateur);
    }

    public boolean estDedans() {
        return this.posY < 500 - this.taille;
    }

    public void attraper() {
        this.attrape = true;
    }

    public void incrementerCycleFin() {
        this.cycleFin++;
    }

    public boolean finCycleFin() {
        return this.cycleFin % 10 == 0;
    }
}