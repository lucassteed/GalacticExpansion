/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjavapise;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

import static projetjavapise.Constantes.*;

/**
 *
 * @author toshiba
 */
public class Astre {

    private Vector<Image> etatsAsteroide = new Vector<>();
    private int taille = new Random().nextInt(51) + 20;
    private int posX = new Random().nextInt(LARGEUR_ECRAN + 1 - (this.taille));
    private int posY = - 1 * this.taille;
    private int vies = new Random().nextInt(3) + 1;
    private int cyclesFin = 10;
    private int accelerateur = new Random().nextInt(7) + 1;

    public Astre() {
        this.etatsAsteroide.add(ASTEROIDE4);
        this.etatsAsteroide.add(ASTEROIDE3);
        this.etatsAsteroide.add(ASTEROIDE2);
        this.etatsAsteroide.add(ASTEROIDE1);
    }

    public int getLimite() {
        return this.posY + this.taille;
    }

    public int getGauche() {
        return this.posX - 10;
    }

    public int getDroite() {
        return this.posX + this.taille + 10;
    }

    public void dessiner(Graphics g) {
        g.drawImage(this.etatsAsteroide.get(this.vies), this.posX, this.posY, this.taille, this.taille, null);
    }

    public void deplacer() {
        this.posY += (1 * this.accelerateur);
    }

    public boolean estDedans() {
        return this.posY < 550 - this.taille;
    }

    public void enleverVie() {
        this.vies--;
    }

    public boolean estVivant() {
        return this.vies > 0;
    }

    public void enleverCycleFin() {
        this.cyclesFin--;
    }

    public boolean finCycleFin() {
        return this.cyclesFin == 0;
    }
}